# Idle Breakout Save Hack
This hack is an extremely basic python script.

# How to Run:

If your on a computer download python 3 and run the file.

Steps to run on a computer: Run the file, follow the text, then copy whats inside the quotes. Copy the text and paste it into the import section of the Idle Breakout Settings

OR it can be run in your browser by going to this link: https://idlebreakout.xsus0.repl.run/

Steps to run in browser:

Click the link, wait for the console to load, then simply follow the instructions and just copy what is *INSIDE* the quotation marks

# Versions


# v1.1
Fixed prestige bug

# v1.0
Initial release


[![HitCount](http://hits.dwyl.io/Xsus0/idlebreakouthack.svg)](http://hits.dwyl.io/Xsus0/idlebreakouthack)
